rm -f assignment3.zip 
zip -r assignment3.zip . -x "*.pyc" "*.git*" "*collect_submission.sh" 